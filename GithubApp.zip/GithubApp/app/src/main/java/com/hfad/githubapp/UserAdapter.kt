package com.hfad.githubapp

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView


class UserAdapter internal constructor(private val context: Context) : BaseAdapter(){

    internal var users = ArrayList<User>()
    override fun getCount(): Int = users.size

    override fun getItem(position: Int): Any =users[position]


    override fun getItemId(position: Int): Long = position.toLong()


    override fun getView(position: Int, v: View?, parent: ViewGroup?):View {
        var itemView = v
        if (itemView == null) {
            itemView = LayoutInflater.from(context).inflate(R.layout.item_user, parent, false)
        }
        val viewHolder = ViewHolder(itemView as View)

        val user = getItem(position) as User
        viewHolder.bind(user)
        return itemView

    }

    private inner class ViewHolder(view: View) {
     fun bind(user: User) {
            txtname.text = user.name
            txtcompany.text = user.company
            txtlocation.text = user.location
            avataruser.setImageResource(user.avatar)
        }

        private val txtname :TextView = view.findViewById(R.id.tv_nama)
//        private val txtFollowing :TextView = view.findViewById(R.id.tv_following)
//        private val txtFollowers :TextView = view.findViewById(R.id.tv_followers)
//        private val txtRepo :TextView = view.findViewById(R.id.tv_repositories)
        private val txtlocation :TextView = view.findViewById(R.id.tv_location)
        private val txtcompany : TextView = view.findViewById(R.id.tv_company)
        private val avataruser : ImageView = view.findViewById(R.id.img_photo)
    }


}