package com.hfad.githubapp

import android.content.Intent
import android.content.res.TypedArray
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.AdapterView
import android.widget.ListView

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: UserAdapter
    private lateinit var dataName: Array<String>
    private lateinit var datacompany: Array<String>
    private lateinit var datalocation: Array<String>
    private lateinit var dataphoto: TypedArray
    private lateinit var datafollowing: TypedArray
    private lateinit var datafollower: TypedArray
    private lateinit var datausername: Array<String>
    private lateinit var datarepository: TypedArray

    private var users = arrayListOf<User>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val listView: ListView = findViewById(R.id.lv_user)
        adapter = UserAdapter(this)
        listView.adapter = adapter

        prepare()
        addItem()

        listView.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            val moveIntent = Intent(this@MainActivity, DetailActivity::class.java)
            val selecteduser :User = users[position]
            moveIntent.putExtra(DetailActivity.EXTRA_USER,selecteduser)
            startActivity(moveIntent)
        }
    }

    private fun addItem() {
        for (position in dataName.indices) {
            val user = User(
                dataphoto.getResourceId(position, 0),
                dataName[position],
                datacompany[position],
                datalocation[position],
                datausername[position],
                datarepository.getInt(position,0),
                datafollowing.getInt(position, 0),
                datafollower.getInt(position, 0)
            )
            users.add(user)
        }
        adapter.users = users
    }

    private fun prepare() {
        dataName = resources.getStringArray(R.array.data_name)
        datacompany = resources.getStringArray(R.array.data_company)
        datalocation = resources.getStringArray(R.array.data_location)
        dataphoto = resources.obtainTypedArray(R.array.photo_avatar)
        datafollower = resources.obtainTypedArray(R.array.data_followers)
        datafollowing = resources.obtainTypedArray(R.array.data_following)
        datarepository = resources.obtainTypedArray(R.array.data_repository)
        datausername = resources.getStringArray(R.array.data_username)


    }

}