package com.hfad.githubapp


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView


class DetailActivity : AppCompatActivity() {
    companion object{
        const val EXTRA_USER = "extra_user"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        val tvusername:TextView = findViewById(R.id.tv_username)
        val tvname :TextView = findViewById(R.id.tv_name)
        val tvfollowing :TextView = findViewById(R.id.tv_following)
        val tvfollowers : TextView = findViewById(R.id.tv_followers)
        val tvcompany  : TextView = findViewById(R.id.tv_company)
        val tvlocation :  TextView = findViewById(R.id.tv_location)
        val repo : TextView  = findViewById(R.id.tv_repositories)
        val photo : ImageView = findViewById(R.id.img_photo)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val data = intent.getParcelableExtra<User>(EXTRA_USER) as User
        supportActionBar?.title = data.name
        tvusername.text = data.username
        tvname.text = data.name
        tvfollowing.text = data.following.toString()
        tvfollowers.text = data.followers.toString()
        tvcompany.text = data.company
        tvlocation.text = data.location
        repo.text = data.repository.toString()
        photo.setImageResource(data.avatar)
    }

}